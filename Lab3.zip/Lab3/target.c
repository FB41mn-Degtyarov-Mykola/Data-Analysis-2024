#include <stdio.h>

int main() {
    char buf[256];
    while (1) {
        printf("Enter input: ");
        fgets(buf, sizeof(buf), stdin);  // Читання вводу
        printf("You entered: %s", buf);  // Виведення введеного значення
        printf("Printing stack addresses:\n");
        printf("%p %p %p %p\n", (void *)&buf, (void *)main, (void *)printf);  // Виведення адрес буфера, функції main, функції printf
        fflush(stdout);  // Очистка буфера виводу
    }
}
