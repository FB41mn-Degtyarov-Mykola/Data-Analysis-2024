#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void fmmylxbg() { puts("Kitty says fmmylxbg!"); }
void mmrusarj() { puts("Kitty says mmrusarj!"); }
void ldwjeloc() { puts("Kitty says ldwjeloc!"); }
// void win() { execv("/bin/sh", 0); } // Видалено функцію win()
void vklybiss() { puts("Kitty says vklybiss!"); }

int main() {
    int pwd[9] = { 0 };
    char buf[9] = { 0 };

    fgets(buf, sizeof(buf), stdin);
    if (pwd[0] != 1337) {
        exit(1);
    } else {
        puts("ACCESS GRANTED!");
    }
}
